﻿CREATE PROCEDURE [190305].[USP_SearchEmpbyEmail]	
	@empemail varchar(30)
AS
begin
	if(@empemail is null )
		Begin 
			Raiserror ('Employee email id cannot be null or empty',1,1)
		end
		Else		
			Begin
				Select * from [190305].EMPLOYEE_EMS where email = @empemail
			End
	End
RETURN 0
