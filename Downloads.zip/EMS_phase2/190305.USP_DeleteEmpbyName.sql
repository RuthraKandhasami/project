﻿CREATE PROCEDURE [190305].[USP_DeleteEmpbyName]
	@empname varchar(30) 	
AS
begin
	if(@empname is null )
		Begin 
			Raiserror ('Employee name cannot be null or empty',1,1)
		end
		Else		
			Begin
			if exists (select EmployeeName from [190305].EMPLOYEE_EMS where EmployeeName = @empname  ) 
			Begin
						delete from [190305].EMPLOYEE_EMS where EmployeeName = @empname
			End		
			Else
			Begin
					RaisError('Employee name  not Exists',1,1)
			end
		end
	end
RETURN 0
