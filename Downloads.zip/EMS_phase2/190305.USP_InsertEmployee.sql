﻿CREATE PROCEDURE [190305].[USP_InsertEmployee]
	@empid int out,
	@empname varchar(30),
	@kinId int,
	@dob date,
	@mobNo varchar(10),
	@email varchar(20),
	@doj date,
	@eadd varchar(100),
	@deptid int ,
	@projectid int ,
	@roleid int 
AS
	insert into [190305].[EMPLOYEE_EMS] values (@empname,@kinId,@email,@dob,@mobno,@doj,@eadd,@deptid,@projectid,@roleid)
	set @empid=SCOPE_IDENTITY() 
RETURN 0

--DROP PROCEDURE [190305].[USP_InsertEmployee]