﻿CREATE PROCEDURE [190305].[USP_DeleteEmpbyEmail]
	@empemail varchar(30) 	
AS
begin
	if(@empemail  is null )
		Begin 
			Raiserror ('Employee Email cannot be null or empty',1,1)
		end
		Else		
			Begin
			if exists (select EmailId from [190305].EMPLOYEE_EMS where EmailId = @empemail   ) 
			Begin
						delete from [190305].EMPLOYEE_EMS where EmailId = @empemail 
			End		
			Else
			Begin
					RaisError('Employee Email  not Exists',1,1)
			end
		end
	end
RETURN 0

