﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entity; //adding reference of entity layer
using EMS_Exceptions; //adding reference of exception layer
using System.Configuration; //addding instance of Sytem Configuration
using System.Data.SqlClient;  //addding instance of SQL Database
using System.Data;      //addding instance of Data table

namespace EMS_DAL
{
    public class EmployeeDAL
    {
        static SqlConnection cn = null; 
        static SqlCommand cmd = null;
        static SqlDataReader dr = null;

        public EmployeeDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public int InsertEmpDAL(Employee emp)
        {
            int empid;
            try
            {
                cmd = new SqlCommand("[190305].[USP_InsertEmployee]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                SqlParameter eid = new SqlParameter("@empid", System.Data.SqlDbType.Int);
                eid.Direction = System.Data.ParameterDirection.Output;
                cmd.Parameters.Add(eid);
                cmd.Parameters.AddWithValue("@empname", emp.EMPname);
                cmd.Parameters.AddWithValue("@kinId", emp.KINid);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@mobNo", emp.PHONEno);            
                cmd.Parameters.AddWithValue("@email", emp.Emailid);
                cmd.Parameters.AddWithValue("@doj", emp.JoiningDate);
                cmd.Parameters.AddWithValue("@eadd", emp.EMPadd);
                cmd.Parameters.AddWithValue("@deptid", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@projectid", emp.ProjectID);
                cmd.Parameters.AddWithValue("@roleid", emp.RoleID);
                cn.Open();
                cmd.ExecuteNonQuery();
                empid = Convert.ToInt32(cmd.Parameters["@empid"].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return empid;
        }

        public bool UpdateEmpbyIDDAL(Employee emp)
        {
            bool empupdated = false;
            try
            {
                cmd = new SqlCommand("[190305].[USP_UpdateEmployeebyID]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@empid", emp.EMPid);
                cmd.Parameters.AddWithValue("@empname", emp.EMPname);
                cmd.Parameters.AddWithValue("@kinId", emp.KINid);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@mobNo", emp.PHONEno);
                cmd.Parameters.AddWithValue("@email", emp.Emailid);
                cmd.Parameters.AddWithValue("@doj", emp.JoiningDate);
                cmd.Parameters.AddWithValue("@eadd", emp.EMPadd);
                cmd.Parameters.AddWithValue("@deptid", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@projectid", emp.ProjectID);
                cmd.Parameters.AddWithValue("@roleid", emp.RoleID);
                empupdated = true;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return empupdated;
        }
        public bool UpdateEmpbyNameDAL(Employee emp)
        {
            bool empupdated = false;
            try
            {
                cmd = new SqlCommand("[190305].[USP_UpdateEmployeebyName]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@empid", emp.EMPid);
                cmd.Parameters.AddWithValue("@empname", emp.EMPname);
                cmd.Parameters.AddWithValue("@kinId", emp.KINid);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@mobNo", emp.PHONEno);
                cmd.Parameters.AddWithValue("@email", emp.Emailid);
                cmd.Parameters.AddWithValue("@doj", emp.JoiningDate);
                cmd.Parameters.AddWithValue("@eadd", emp.EMPadd);
                cmd.Parameters.AddWithValue("@deptid", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@projectid", emp.ProjectID);
                cmd.Parameters.AddWithValue("@roleid", emp.RoleID);
                empupdated = true;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return empupdated;
        }
        public bool UpdateEmpbyEmailDAL(Employee emp)
        {
            bool empupdated = false;
            try
            {
                cmd = new SqlCommand("[190305].[USP_UpdateEmployeebyEmail]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@empid", emp.EMPid);
                cmd.Parameters.AddWithValue("@empname", emp.EMPname);
                cmd.Parameters.AddWithValue("@kinId", emp.KINid);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@mobNo", emp.PHONEno);
                cmd.Parameters.AddWithValue("@email", emp.Emailid);
                cmd.Parameters.AddWithValue("@doj", emp.JoiningDate);
                cmd.Parameters.AddWithValue("@eadd", emp.EMPadd);
                cmd.Parameters.AddWithValue("@deptid", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@projectid", emp.ProjectID);
                cmd.Parameters.AddWithValue("@roleid", emp.RoleID);
                empupdated = true;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return empupdated;
        }

        public Employee SearchbyKINidDAL(int id)
        {
            Employee emp = null;
            try
            {
                cmd = new SqlCommand("[190305].[USP_SearchEmpbyID]", cn);
                cmd.Parameters.AddWithValue("@kinid", id);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    emp = new Employee();
                    emp.EMPid = Convert.ToInt32(dr[0]);
                    emp.EMPname = dr[1].ToString();
                    emp.KINid = Convert.ToInt32(dr[2]);
                    emp.Emailid = dr[3].ToString();
                    emp.DOB = Convert.ToDateTime(dr[4]);
                    emp.PHONEno = dr[5].ToString();
                    emp.JoiningDate = Convert.ToDateTime(dr[6]);
                    emp.EMPadd = dr[7].ToString();
                    emp.DepartmentID = Convert.ToInt32(dr[8]);
                    emp.ProjectID = Convert.ToInt32(dr[9]);
                    emp.RoleID = Convert.ToInt32(dr[10]);
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return emp;
        }

        public List<Employee> SearchbyNameDAL(string name)
        {
            List<Employee> emplist = new List<Employee>();
            try
            {
                cmd = new SqlCommand("[190305].[USP_SearchEmpbyName]", cn);
                cmd.Parameters.AddWithValue("@empname", name);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Employee emp = new Employee();
                    emp.EMPid = Convert.ToInt32(dr[0]);
                    emp.EMPname = dr[1].ToString();
                    emp.KINid = Convert.ToInt32(dr[2]);
                    emp.Emailid = dr[3].ToString();
                    emp.DOB = Convert.ToDateTime(dr[4]);
                    emp.PHONEno = dr[5].ToString();
                    emp.JoiningDate = Convert.ToDateTime(dr[6]);
                    emp.EMPadd = dr[7].ToString();
                    emp.DepartmentID = Convert.ToInt32(dr[8]);
                    emp.ProjectID = Convert.ToInt32(dr[9]);
                    emp.RoleID = Convert.ToInt32(dr[10]);
                    emplist.Add(emp);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return emplist;
        }

        public Employee SearchbyEmailDAL(string email)
        {
            Employee emp = null; 
            try
            {
                cmd = new SqlCommand("[190305].[USP_SearchEmpbyEmail]", cn);
                cmd.Parameters.AddWithValue("@empemail", email);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    emp = new Employee();
                    emp.EMPid = Convert.ToInt32(dr[0]);
                    emp.EMPname = dr[1].ToString();
                    emp.KINid = Convert.ToInt32(dr[2]);
                    emp.Emailid = dr[3].ToString();
                    emp.DOB = Convert.ToDateTime(dr[4]);
                    emp.PHONEno = dr[5].ToString();
                    emp.JoiningDate = Convert.ToDateTime(dr[6]);
                    emp.EMPadd = dr[7].ToString();
                    emp.DepartmentID = Convert.ToInt32(dr[8]);
                    emp.ProjectID = Convert.ToInt32(dr[9]);
                    emp.RoleID = Convert.ToInt32(dr[10]);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return emp;
        }
        
        public bool DeleteEmpbyIdDAL(int id)
        {
            bool empdeleted = false;
            try
            {
                cmd = new SqlCommand("[190305].[USP_DeleteEmpbyID]", cn);
                cmd.Parameters.AddWithValue("@kinid", id);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                
                cn.Open();
                cmd.ExecuteNonQuery();
                empdeleted = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return empdeleted;
        }

        public bool DeleteEmpbyNameDAl(string Name)
        {
            bool empdeleted = false;
            try
            {
                cmd = new SqlCommand("[190305].[USP_DeleteEmpbyName]", cn);
                cmd.Parameters.AddWithValue("@empname", Name);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                empdeleted = true;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return empdeleted;
        }

        public bool DeleteEmpbyEmailDAL(string email)
        {
            bool empdeleted = false;
            try
            {
                cmd = new SqlCommand("[190305].[USP_DeleteEmpbyEmail]", cn);
                cmd.Parameters.AddWithValue("@empemail", email);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                empdeleted = true;
                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return empdeleted;
        }

        public List<Employee> GetAllDAL()
        {
            List<Employee> emplist = new List<Employee>();
            try
            {
                cmd = new SqlCommand("[190305].[USP_ListEmployee]", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Employee emp = new Employee();
                    emp.EMPid = Convert.ToInt32(dr[0]);
                    emp.EMPname = dr[1].ToString();
                    emp.KINid = Convert.ToInt32(dr[2]);
                    emp.Emailid = dr[3].ToString();
                    emp.DOB = Convert.ToDateTime(dr[4]);
                    emp.PHONEno = dr[5].ToString();
                    emp.JoiningDate = Convert.ToDateTime(dr[6]);
                    emp.EMPadd = dr[7].ToString();
                    emp.DepartmentID = Convert.ToInt32(dr[8]);
                    emp.ProjectID = Convert.ToInt32(dr[9]);
                    emp.RoleID = Convert.ToInt32(dr[10]);
                    emplist.Add(emp);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return emplist;
        }    

        public DataTable GetDepartmentDAL()
        {
            DataTable deptlist = null;
            try
            {
                cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
                cmd = new SqlCommand("[190305].[USP_getDepartment]", cn); 
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                SqlDataReader objDR = cmd.ExecuteReader();
                deptlist = new DataTable();
                deptlist.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return deptlist;
        }

        public DataTable GetProjectDAL()
        {
            DataTable projectlist = null;
            try
            {
                cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
                cmd = new SqlCommand("[190305].[USP_getProject]", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                SqlDataReader objDR = cmd.ExecuteReader();
                projectlist = new DataTable();
                projectlist.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return projectlist;
        }

        public DataTable GetRoleDAL()
        {
            DataTable rolelist = null;
            try
            {
                cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
                cmd = new SqlCommand("[190305].[USP_getRole]", cn); 
                cmd.CommandType = CommandType.StoredProcedure;
                cn.Open();
                SqlDataReader objDR = cmd.ExecuteReader();
                rolelist = new DataTable();
                rolelist.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return rolelist;
        }
    }
}
