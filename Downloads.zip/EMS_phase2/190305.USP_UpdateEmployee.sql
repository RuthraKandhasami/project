﻿create procedure [190305].[USP_UpdateEmployee]
	@empid int ,
	@empname varchar(30),
	@kinId int,
	@dob date,
	@mobNo varchar(10),
	@email varchar(20),
	@doj date,
	@eadd varchar(100),
	@deptid int ,
	@projectid int ,
	@roleid int 
AS
BEGIN
		if (@kinId is null OR @kinId <0 ) 
		BEGIN
			RaisError('KIN Id cannot be null or empty',1,1)
		END
	ELSE
		BEGIN
			if exists (select kinId from [190305].EMPLOYEE_EMS where kinId = @kinId ) 
			BEGIN
				update [190305].EMPLOYEE_EMS set
				 EmployeeName = @empname,
				 kinId = @kinId,
				 EmailId = @email,
				 DOB = @deptid,
				 Contact = @mobNo,
				 DOJ = @doj,
				 EmployeeAddress = @eadd,
				 DepartmentId = @deptid,
				 ProjectId = @projectid,
				 RoleId = @roleid
				 where 
				 kinId = @kinId
			End
		Else
			Begin
					RaisError('KIN ID not Exists',1,1)
			end
		end
	end
RETURN 0
