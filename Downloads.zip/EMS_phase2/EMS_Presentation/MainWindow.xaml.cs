﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EMS_BL;
using EMS_Exceptions;
using EMS_Entity;
using System.Data;

namespace EMS_Presentation
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        EmployeeBL empbl = new EmployeeBL();

        public MainWindow()
        {
            InitializeComponent();
            GetDeptList();
            GetProjectList();
            GetRoleList();
            txtemp.Visibility = Visibility.Hidden;
            dgEmployee.Visibility = Visibility.Hidden;
        }

        private void Populate()
        {
            try
            {
                List<Employee> emp = empbl.GetAllEmployeeBL();
                dgEmployee.ItemsSource = emp;
            }
            catch (Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
        }

        private void Clear()
        {
            txtemp.Text = txtKin.Text = txtname.Text = txtdob.Text = txtmob.Text = txtemail.Text = txtdoj.Text = txtadd.Text = string.Empty;
            cmbdept.SelectedIndex = cmbproj.SelectedIndex = cmbrole.SelectedIndex = update.SelectedIndex =  -1;
            byID.IsChecked = byName.IsChecked = byEmail.IsChecked = false;
        }

        private void BtnSubmit_Click(object sender, RoutedEventArgs e)
        {
            Employee emp = new Employee();
            
            int id;
            try
            {
                emp.EMPname = txtname.Text;
                try
                {
                    emp.KINid = Convert.ToInt32(txtKin.Text);
                }
                catch (Exception)
                {
                     MessageBox.Show("Enter Kin Id");
                }
                emp.DOB = Convert.ToDateTime(txtdob.SelectedDate);
                emp.PHONEno = txtmob.Text;
                emp.Emailid = txtemail.Text;
                emp.JoiningDate = Convert.ToDateTime(txtdoj.SelectedDate);
                emp.EMPadd = txtadd.Text;
                if (cmbdept.SelectedValue == null)
                {
                    MessageBox.Show("Select any department");
                }
                else
                {
                    emp.DepartmentID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                if (cmbproj.SelectedValue == null)
                {
                    MessageBox.Show("Select any project");
                }
                else
                {
                    emp.ProjectID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                if (cmbrole.SelectedValue == null)
                {
                    MessageBox.Show("Select any role");
                }
                else
                {
                    emp.RoleID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                id = empbl.AddEmpBL(emp);
                if (id != 0)
                {
                    MessageBox.Show("Employee Record Inserted with Employee Id : " + id);
                }
                else
                {
                    MessageBox.Show("Record Could not be Inserted" );
                }
                Populate();
                Clear();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void UpdateById()
        {
            Employee emp = new Employee();
            bool result;
            try
            {
                emp.EMPname = txtname.Text;
                try
                {
                    emp.KINid = Convert.ToInt32(txtKin.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Enter Kin Id");
                }
                emp.DOB = Convert.ToDateTime(txtdob.SelectedDate);
                emp.PHONEno = txtmob.Text;
                emp.Emailid = txtemail.Text;
                emp.JoiningDate = Convert.ToDateTime(txtdoj.SelectedDate);
                emp.EMPadd = txtadd.Text;
                if (cmbdept.SelectedValue == null)
                {
                    MessageBox.Show("Select any department");
                }
                else
                {
                    emp.DepartmentID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                if (cmbproj.SelectedValue == null)
                {
                    MessageBox.Show("Select any project");
                }
                else
                {
                    emp.ProjectID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                if (cmbrole.SelectedValue == null)
                {
                    MessageBox.Show("Select any role");
                }
                else
                {
                    emp.RoleID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                result = empbl.ModifyEmpbyIDBL(emp);
                if (result == true)
                {
                    MessageBox.Show("Record Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Record could not be updated");
                }
                Populate();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetDeptList()
        {
            try
            {
                DataTable blkList = EmployeeBL.GetdeptBL();
                cmbdept.ItemsSource = blkList.DefaultView;
                cmbdept.DisplayMemberPath = blkList.Columns[1].ColumnName;
                cmbdept.SelectedValuePath = blkList.Columns[0].ColumnName;
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetProjectList()
        {
            try
            {
                DataTable projectList = EmployeeBL.GetprojectBL();
                cmbproj.ItemsSource = projectList.DefaultView;
                cmbproj.DisplayMemberPath = projectList.Columns[1].ColumnName;
                cmbproj.SelectedValuePath = projectList.Columns[0].ColumnName;
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GetRoleList()
        {
            try
            {
                DataTable roleList = EmployeeBL.GetRoleBL();
                cmbrole.ItemsSource = roleList.DefaultView;
                cmbrole.DisplayMemberPath = roleList.Columns[1].ColumnName;
                cmbrole.SelectedValuePath = roleList.Columns[0].ColumnName;
            }
            catch (EmployeeException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnsearch2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int KinId = int.Parse(txtKin.Text);
                Employee emp = empbl.SearchEmpbyKinIDBL(KinId);
                if(emp != null)
                {
                    txtemp.Visibility = Visibility.Visible;
                    txtemp.Text = "Employee Id: "+emp.EMPid.ToString();
                    txtKin.Text = emp.KINid.ToString();
                    txtname.Text = emp.EMPname.ToString();
                    txtdob.Text = emp.DOB.ToShortDateString().ToString();
                    txtmob.Text = emp.PHONEno.ToString();
                    txtemail.Text = emp.Emailid.ToString();
                    txtdoj.Text = emp.JoiningDate.ToShortDateString().ToString();
                    txtadd.Text = emp.EMPadd.ToString();
                    cmbdept.SelectedValue = emp.DepartmentID;
                    cmbproj.SelectedValue = emp.ProjectID;
                    cmbrole.SelectedValue = emp.RoleID;                   
                }
                else
                {
                    MessageBox.Show("Could not find Employee");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnsearch1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = txtname.Text;
                List<Employee> employees = empbl.SearchEmpbyNameBL(name);
                if (employees.Count >= 1)
                {
                    txtemp.Visibility = Visibility.Visible;
                    txtemp.Text = "Employee Id: " +employees[0].EMPid.ToString();
                    txtKin.Text = employees[0].KINid.ToString();
                    txtname.Text = employees[0].EMPname.ToString();
                    txtdob.Text = employees[0].DOB.ToShortDateString().ToString();
                    txtmob.Text = employees[0].PHONEno.ToString();
                    txtemail.Text = employees[0].Emailid.ToString();
                    txtdoj.Text = employees[0].JoiningDate.ToShortDateString().ToString();
                    txtadd.Text = employees[0].EMPadd.ToString();
                    cmbdept.SelectedValue = employees[0].DepartmentID;
                    cmbproj.SelectedValue = employees[0].ProjectID;
                    cmbrole.SelectedValue = employees[0].RoleID;
                }
                else
                {
                    MessageBox.Show("Could not find Employee");
                }

                if (employees.Count > 1)
                {
                    txtemp.Visibility = Visibility.Hidden;
                    Clear();
                    dgEmployee.Visibility = Visibility.Visible;
                    dgEmployee.ItemsSource = employees;                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnsearch3_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string email = txtemail.Text;
                Employee emp = empbl.SearchEmpbyEmailBL(email);
                if (emp != null)
                {
                    txtemp.Visibility = Visibility.Visible;
                    txtemp.Text = "Employee Id: " + emp.EMPid.ToString();
                    txtKin.Text = emp.KINid.ToString();
                    txtname.Text = emp.EMPname.ToString();
                    txtdob.Text = emp.DOB.ToShortDateString().ToString();
                    txtmob.Text = emp.PHONEno.ToString();
                    txtemail.Text = emp.Emailid.ToString();
                    txtdoj.Text = emp.JoiningDate.ToShortDateString().ToString();
                    txtadd.Text = emp.EMPadd.ToString();
                    cmbdept.SelectedValue = emp.DepartmentID;
                    cmbproj.SelectedValue = emp.ProjectID;
                    cmbrole.SelectedValue = emp.RoleID;
                }
                else
                {
                    MessageBox.Show("Could not find Employee");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void deletebyID()
        {
            Employee emp = new Employee();
            try
            {
                bool result;
                emp.KINid = Convert.ToInt32(txtKin.Text);
                if(empbl.SearchEmpbyKinIDBL(emp.KINid) != null)
                {                    
                    MessageBoxResult ans = MessageBox.Show("Are you sure ??","" ,MessageBoxButton.YesNo);
                    if (ans == MessageBoxResult.Yes)
                    {
                        result = empbl.RemoveEmpbyIdBL(emp.KINid);
                        if (result == true)
                        {
                            MessageBox.Show("Record Deleted Successfully");
                        }
                        else
                        {
                            MessageBox.Show("Record could not be deleted");
                        }                        
                    }
                    else
                    {
                        MessageBox.Show("Delete operation successfully canceled");
                    }
                }
                else
                {
                    MessageBox.Show("Record does not exist");
                }                   
                Populate();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void deletebyName()
        {
            Employee emp = new Employee();
            try
            {
                bool result;
                emp.EMPname = txtname.Text;
                if (empbl.SearchEmpbyNameBL(emp.EMPname).Count<1)
                {
                    MessageBox.Show("Record does not exist");
                   
                }
                else
                {
                    MessageBoxResult ans = MessageBox.Show("Are you sure ??", "", MessageBoxButton.YesNo);
                    if (ans == MessageBoxResult.Yes)
                    {
                        result = empbl.RemoveEmpbyNameBL(emp.EMPname);
                        if (result == true)
                        {
                            MessageBox.Show("Record Deleted Successfully");
                        }
                        else
                        {
                            MessageBox.Show("Record could not be deleted");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Delete operation successfully canceled");
                    }
                }
                Populate();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void deletebyemail()
        {
            Employee emp = new Employee();
            try
            {
                bool result;
                emp.Emailid = txtemail.Text;
                if (empbl.SearchEmpbyEmailBL(emp.Emailid) != null)
                {
                    MessageBoxResult ans = MessageBox.Show("Are you sure ??", "", MessageBoxButton.YesNo);
                    if (ans == MessageBoxResult.Yes)
                    {
                        result = empbl.RemoveEmpbyEmailBL(emp.Emailid);
                        if (result == true)
                        {
                            MessageBox.Show("Record Deleted Successfully");
                        }
                        else
                        {
                            MessageBox.Show("Record could not be deleted");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Delete operation successfully canceled");
                    }
                }
                else
                {
                    MessageBox.Show("Record does not exist");
                }
                Populate();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void UpdateByEmail()
        {
            Employee emp = new Employee();
            bool result;
            try
            {
                emp.EMPname = txtname.Text;
                try
                {
                    emp.KINid = Convert.ToInt32(txtKin.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Enter Kin Id");
                }
                emp.DOB = Convert.ToDateTime(txtdob.SelectedDate);
                emp.PHONEno = txtmob.Text;
                emp.Emailid = txtemail.Text;
                emp.JoiningDate = Convert.ToDateTime(txtdoj.SelectedDate);
                emp.EMPadd = txtadd.Text;
                if (cmbdept.SelectedValue == null)
                {
                    MessageBox.Show("Select any department");
                }
                else
                {
                    emp.DepartmentID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                if (cmbproj.SelectedValue == null)
                {
                    MessageBox.Show("Select any project");
                }
                else
                {
                    emp.ProjectID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                if (cmbrole.SelectedValue == null)
                {
                    MessageBox.Show("Select any role");
                }
                else
                {
                    emp.RoleID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                result = empbl.ModifyEmpbyEmailBL(emp);
                if (result == true)
                {
                    MessageBox.Show("Record Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Record could not be updated");
                }
                Populate();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void UpdateByName()
        {
            Employee emp = new Employee();
            bool result;
            try
            {
                emp.EMPname = txtname.Text;
                try
                {
                    emp.KINid = Convert.ToInt32(txtKin.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Enter Kin Id");
                }
                emp.DOB = Convert.ToDateTime(txtdob.SelectedDate);
                emp.PHONEno = txtmob.Text;
                emp.Emailid = txtemail.Text;
                emp.JoiningDate = Convert.ToDateTime(txtdoj.SelectedDate);
                emp.EMPadd = txtadd.Text;
                if (cmbdept.SelectedValue == null)
                {
                    MessageBox.Show("Select any department");
                }
                else
                {
                    emp.DepartmentID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                if (cmbproj.SelectedValue == null)
                {
                    MessageBox.Show("Select any project");
                }
                else
                {
                    emp.ProjectID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                if (cmbrole.SelectedValue == null)
                {
                    MessageBox.Show("Select any role");
                }
                else
                {
                    emp.RoleID = Convert.ToInt32(cmbdept.SelectedValue);
                }
                result = empbl.ModifyEmpbyNameBL(emp);
                if (result == true)
                {
                    MessageBox.Show("Record Updated Successfully");
                }
                else
                {
                    MessageBox.Show("Record could not be updated");
                }
                Populate();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnview_Click(object sender, RoutedEventArgs e)
        {
            dgEmployee.Visibility = Visibility.Visible;
            Populate();
        }

        private void Btnclose_Click(object sender, RoutedEventArgs e)
        {
            dgEmployee.Visibility = Visibility.Hidden;
        }

        private void Update_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
           
            if (update.SelectedIndex == 0)
                UpdateById();
            if (update.SelectedIndex == 1)
                UpdateByName();
            if (update.SelectedIndex == 2)
                UpdateByEmail();
            Clear();
        }

        private void ByID_Checked(object sender, RoutedEventArgs e)
        {
            deletebyID();
        }

        private void ByName_Checked(object sender, RoutedEventArgs e)
        {
            deletebyName();
        }

        private void ByEmail_Checked(object sender, RoutedEventArgs e)
        {
            deletebyemail();
        }

        private void Btnclear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
