﻿CREATE PROCEDURE [190305].[SearchEmpbyName]	
	@empname varchar(30)
AS
begin
	if(@empname is null )
		Begin 
			Raiserror ('Employee name cannot be null or empty',1,1)
		end
		Else		
			Begin
				Select * from [190305].EMPLOYEE_EMS where EmployeeName = @empname
			End
	End
RETURN 0