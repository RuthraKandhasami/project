﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Entity
{
    public class Employee // entity class
    {
        // declaring variables for using in properties
        int Empid, KinId, Projectid, Departmentid, Roleid;
        string EmpName, EmpAdd, emailId, PhoneNo;
        DateTime Dob, DateofJoining;

        //declaring properties
        public int EMPid
        {
            get
            {
                return Empid;

            }
            set
            {
                Empid = value;
            }
        }

        public int KINid
        {
            get
            {
                return KinId;

            }
            set
            {
                KinId = value;
            }
        }

        public string EMPname
        {
            get
            {
                return EmpName;

            }
            set
            {
                EmpName = value;
            }
        }

        public string EMPadd
        {
            get
            {
                return EmpAdd;

            }
            set
            {
                EmpAdd = value;
            }
        }

        public string Emailid
        {
            get
            {
                return emailId;

            }
            set
            {
                emailId = value;
            }
        }

        public string PHONEno
        {
            get
            {
                return PhoneNo;

            }
            set
            {
                PhoneNo = value;
            }
        }

        public DateTime DOB
        {
            get
            {
                return Dob;
            }
            set
            {
                Dob = value;
            }
        }

        public DateTime JoiningDate
        {
            get
            {
                return DateofJoining;
            }
            set
            {
                DateofJoining = value;
            }
        }

        public int ProjectID
        {
            get
            {
                return Projectid;

            }
            set
            {
                Projectid = value;
            }
        }

        public int DepartmentID
        {
            get
            {
                return Departmentid;

            }
            set
            {
                Departmentid = value;
            }
        }

        public int RoleID
        {
            get
            {
                return Roleid;

            }
            set
            {
                Roleid = value;
            }
        }

        //initializing all variables to zero/empty using constructor of entity class
        public Employee()
        {
            EMPid = 0;
            KINid = 0;
            EMPname = string.Empty;
            EMPadd = string.Empty;
            Emailid = string.Empty;
            PHONEno = string.Empty;
            DOB = DateTime.MinValue;
            JoiningDate = DateTime.MinValue;
            ProjectID = 0;
            DepartmentID = 0;
            RoleID = 0;
        }
    }
}