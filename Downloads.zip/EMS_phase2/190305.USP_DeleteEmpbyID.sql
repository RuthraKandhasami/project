﻿CREATE PROCEDURE [190305].[USP_DeleteEmpbyID]
	@kinid int 	
AS
begin
	if(@kinid is null OR @kinid <0)
		Begin 
			Raiserror ('KIN Id cannot be null or empty',1,1)
		end
		Else		
			Begin
			if exists (select kinId from [190305].EMPLOYEE_EMS where kinId = @kinid  ) 
			Begin
						delete from [190305].EMPLOYEE_EMS where kinId = @kinid
			End		
			Else
			Begin
					RaisError('KIN ID not Exists',1,1)
			end
		end
	end
RETURN 0
