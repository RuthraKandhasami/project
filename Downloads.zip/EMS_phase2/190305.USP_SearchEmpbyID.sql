﻿CREATE PROCEDURE [190305].[USP_SearchEmpbyID]	
	@kinId int
AS
begin
	if(@kinId is null OR @kinId <0)
		Begin 
			Raiserror ('KIN Id cannot be null or empty',1,1)
		end
		Else		
			Begin
			Select * from [190305].EMPLOYEE_EMS where kinId = @kinId
			End
	End
RETURN 0
