﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Exceptions
{
    public class EmployeeException : ApplicationException  //inheriting System exception
    {
        public EmployeeException() : base() //base class exception
        {

        }

        public EmployeeException(string message) : base(message) //derived class exception
        {

        }

        public EmployeeException(string message, Exception innerexception) : base(message, innerexception)
        {

        }
    }
}
