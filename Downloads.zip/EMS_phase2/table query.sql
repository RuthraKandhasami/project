﻿--Employee Table

CREATE TABLE [190305].[EMPLOYEE_EMS] (
	EmployeeID   INT  IDENTITY  Primary Key ,
    EmployeeName  VARCHAR (30),
	kinId int unique,
	EmailId VARCHAR (20) unique,
    DOB  DATETIME,
    Contact VARCHAR (10),
	DOJ DateTime,
	EmployeeAddress VArchar(100),
    DepartmentId int ,
	ProjectId int ,
	RoleId int ,
	foreign key ([DepartmentId]) references [190305].[DEPARTMENT_EMS] ([DepartmentId]),
	foreign key ([ProjectId]) references [190305].[PROJECT_EMS] ([ProjectId]),
	foreign key ([RoleId]) references [190305].[ROLE_EMS] ([RoleId])
)
select * from [190305].[EMPLOYEE_EMS]
drop table [190305].[EMPLOYEE_EMS]

--Department Table

create table [190305].[DEPARTMENT_EMS]
(
	DepartmentId int Primary key Identity(1,1),
	DepartmentName varchar(50),
	DepartmentDescription varchar(200)
)
drop table [190305].[DEPARTMENT_EMS]
insert into [190305].[DEPARTMENT_EMS] values('HR','For recruiting Employees');
insert into [190305].[DEPARTMENT_EMS] values('Admin','For performing all administration work');
insert into [190305].[DEPARTMENT_EMS] values('Finance','For performing all finance related work');
insert into [190305].[DEPARTMENT_EMS] values('IT','For performing all work related to technology');
select * from [190305].[DEPARTMENT_EMS]


--Project Table

create table [190305].[PROJECT_EMS]
(
	ProjectId int Primary key Identity(1,1),
	ProjectName varchar(50),
	ProjectDescription varchar(200),
	DepartmentId int Foreign key References [190305].[DEPARTMENT_EMS](DepartmentId)
)
drop table [190305].[PROJECT_EMS]
insert into [190305].[PROJECT_EMS] values('Employee Management Sytem','For maintaing records of all employees',1);
insert into [190305].[PROJECT_EMS] values('Student Management Sytem','For maintaing records of all students',2);
insert into [190305].[PROJECT_EMS] values('HR Management Sytem','For maintaing records of HR team',3);
insert into [190305].[PROJECT_EMS] values('Hospital Management Sytem','For maintaing records of all patients,doctors and staff in the hospital ',4);
select * from [190305].[PROJECT_EMS]


--Role Table

create table [190305].[ROLE_EMS]
(
	RoleId int Primary key Identity(1,1),
	RoleName varchar(50),
	RoleDescription varchar(200)
)
drop table [190305].[ROLE_EMS]
insert into [190305].[ROLE_EMS] values('Developer','Job is to develop the software');
insert into [190305].[ROLE_EMS] values('Tester','Job is to test the software');
insert into [190305].[ROLE_EMS] values('Team Leader','Job is to lead the entire team ');
insert into [190305].[ROLE_EMS] values('IMS','Job is to support the software');
select * from [190305].[ROLE_EMS]

