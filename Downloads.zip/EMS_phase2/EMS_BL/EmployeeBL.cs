﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using EMS_DAL;
using EMS_Entity;
using EMS_Exceptions;

namespace EMS_BL
{
    public class EmployeeBL
    {
        EmployeeDAL empdal = new EmployeeDAL();

        public static bool Validate(Employee employee)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;

            if (Convert.ToString(employee.KINid) == null)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Kin ID cannot be empty");
            }
            if (!(Convert.ToString(employee.KINid).Length == 5))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "KIN ID Must Be 5 Digits");
            }
            if (!Regex.Match(Convert.ToString(employee.KINid), "^([0-9])").Success)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "KIN ID should contain only digits");
            }

            if (employee.EMPname == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Name cannot be empty");
            }
            if (!Regex.Match(employee.EMPname, "^[a-zA-Z]").Success)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Name should contain only characters");
            }

            if (!(Convert.ToString(employee.PHONEno).Length == 10))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Mobile no Must Be 10 Digits");
            }
            if (!Regex.Match(Convert.ToString(employee.PHONEno), "^[0-9]").Success)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Phone number should contain only digits");
            }

            if (employee.Emailid == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Email ID cannot be empty");
            }
            if (!Regex.Match(employee.Emailid, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$").Success)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Invalid Email ID");
            }

            if (employee.EMPadd == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Address cannot be empty");
            }
            if (!Regex.Match(employee.EMPadd, "^[a-zA-Z]").Success)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Address should contain only characters");
            }

            if (employee.DOB > DateTime.Today)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Invalid Date Of Birth");
            }

            if (employee.JoiningDate.Year <= (employee.DOB.Year) + 17)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Invalid Date of Joining. Difference between DOB and DOJ should be minimum of 18 years ");
            }

            if (Convert.ToString(employee.DepartmentID) == null)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Select any department");
            }

            if (Convert.ToString(employee.ProjectID) == null)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Select your assigned project");
            }

            if (Convert.ToString(employee.RoleID) == null)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Select your appropriate Role");
            }

            if (validEmployee == false)
            {
                throw new EmployeeException(sb.ToString());
            }
            return validEmployee;
        }

        public int AddEmpBL(Employee emp)
        {
            int empid = 0;
            try
            {
                if (Validate(emp))
                {
                    empid = empdal.InsertEmpDAL(emp);
                }              
            }
            catch(EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empid;
        }

        public bool ModifyEmpbyIDBL(Employee emp)
        {
            bool empupdated = false;
            try
            {
                if (Validate(emp))
                {
                    empupdated = empdal.UpdateEmpbyIDDAL(emp);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empupdated;
        }
        public bool ModifyEmpbyNameBL(Employee emp)
        {
            bool empupdated = false;
            try
            {
                if (Validate(emp))
                {
                    empupdated = empdal.UpdateEmpbyNameDAL(emp);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empupdated;
        }
        public bool ModifyEmpbyEmailBL(Employee emp)
        {
            bool empupdated = false;
            try
            {
                if (Validate(emp))
                {
                    empupdated = empdal.UpdateEmpbyEmailDAL(emp);
                }
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empupdated;
        }
        public Employee SearchEmpbyKinIDBL(int id)
        {
            Employee searchemployee = null;
            try
            {
                searchemployee = empdal.SearchbyKINidDAL(id);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchemployee;
        }

        public List<Employee> SearchEmpbyNameBL(string name)
        {
            List<Employee> searchlist;
            try
            {
                searchlist = empdal.SearchbyNameDAL(name);                
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchlist;
        }

        public Employee SearchEmpbyEmailBL(string email)
        {
            Employee searchemployee = null;
            try
            {
                searchemployee = empdal.SearchbyEmailDAL(email);             
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchemployee;
        }

        public bool RemoveEmpbyIdBL(int id)
        {
            bool empdeleted = false;
            try
            {
               empdeleted = empdal.DeleteEmpbyIdDAL(id);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empdeleted;
        }

        public bool RemoveEmpbyNameBL(string name)
        {
            bool empdeleted = false;
            try
            {
                empdeleted = empdal.DeleteEmpbyNameDAl(name);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empdeleted;
        }

        public bool RemoveEmpbyEmailBL(string email)
        {
            bool empdeleted = false;
            try
            {
                empdeleted = empdal.DeleteEmpbyEmailDAL(email);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empdeleted;
        }

        public List<Employee> GetAllEmployeeBL()
        {
            List<Employee> empList;
            try
            {
                empList = empdal.GetAllDAL();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return empList;
        }

        public static DataTable GetdeptBL()
        {
            DataTable deptlist; // initializing datatable
            try
            {
                EmployeeDAL objdal = new EmployeeDAL();
                deptlist = objdal.GetDepartmentDAL(); 
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return deptlist;
        }

        public static DataTable GetprojectBL()
        {
            DataTable projectlist; // initializing datatable
            try
            {
                EmployeeDAL objdal = new EmployeeDAL();
                projectlist = objdal.GetProjectDAL();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return projectlist;
        }

        public static DataTable GetRoleBL()
        {
            DataTable rolelist; // initializing datatable
            try
            {
                EmployeeDAL objdal = new EmployeeDAL();
                rolelist = objdal.GetRoleDAL();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return rolelist;
        }
    }
}
